## Type pattern of numbers

In file `pattern02.txt` type the following pattern.

![pattern02](./pattern02.png)

## Run Tests
```bash
check50 enhance42/clang/2024/type/pattern02
```

## Submit your work
```bash
submit50 enhance42/clang/2024/type/pattern02
```

**Note:** `Never submit without tests passing`.

