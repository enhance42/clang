## Type pattern of numbers

In file `pattern03.txt` type the following pattern.

![pattern03](./pattern03.png)

## Run Tests
```bash
check50 enhance42/clang/2024/type/pattern03
```

## Submit your work
```bash
submit50 enhance42/clang/2024/type/pattern03
```

**Note:** `Never submit without tests passing`.

