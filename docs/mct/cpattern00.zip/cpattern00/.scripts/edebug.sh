echo "debug50 pattern00"
debug50 pattern00
