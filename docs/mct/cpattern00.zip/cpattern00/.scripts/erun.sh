echo "./pattern00"
./pattern00
