echo "make pattern00"
make pattern00
