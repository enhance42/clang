echo "help50 make pattern00"
help50 make pattern00
