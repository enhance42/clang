echo "style50 pattern00.c"
style50 pattern00.c
