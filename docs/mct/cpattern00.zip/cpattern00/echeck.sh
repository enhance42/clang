echo "check50 enhance42/clang/2024/mct/pattern00"
check50 enhance42/clang/2024/mct/pattern00
