#include "telugu.h"

sankya main()
{
    sankya weight;
    sankya distance = 0;
    sankya kgs2reduce = 0;
    weight = numbertesuko("How much soil do you have? ");
    idhiayyevaraku(weight > 70)
    {
       printf("Do walking of 5 kms, to reduce 2kgs.\n");
       distance = distance + 5;
       kgs2reduce = kgs2reduce + 2;
       weight = weight - 2;
    }
    printf("%i kms nadu", distance);
    printf(" so %i kgs tagguthavu.\n", kgs2reduce);
}
