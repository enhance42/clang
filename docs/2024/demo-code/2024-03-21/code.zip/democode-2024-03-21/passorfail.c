#include "telugu.h"

sankya main()
{
    sankya marks;
    marks = numbertesuko("enni marks vachayi: ");
    idhiayithey(marks >= 35)
    {
        printf("nuvvu pass ayyavu, pandaga chesuko.\n");
    }
    kakapothey
    {
        printf("malli examki prepare avvu.\n");
    }
}
