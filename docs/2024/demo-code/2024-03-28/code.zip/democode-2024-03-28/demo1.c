#include <stdio.h>

int main(void)
{
    int marks[8];
    int i;
    printf("Enter your exam marks for 8 subjects: ");

    i = 0;
    while (i < 8)
    {
        scanf("%d", &marks[i]);
        i = i + 1;
    }

    printf("The marks for 8 subjects are");

    i = 0;
    while (i < 8)
    {
        printf(" %d", marks[i]);
        i = i + 1;
    }
    printf(".\n");

    return 0;
}
