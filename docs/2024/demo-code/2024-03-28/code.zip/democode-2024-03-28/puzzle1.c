#include <stdio.h>
// What is the output of this program?
int main(void)
{
    int res;
    res = printf("0123");
    printf("%d\n", res);
    return 0;
}

/*
#include <stdio.h>

int main(void)
{
    printf("%d\n", printf("0123"));
    return 0;
}
*/
