#include <stdio.h>

int main(void)
{
    int marks[8];
    int i;
    printf("Enter your exam marks for 8 subjects: ");
    for (i = 0; i < 8; i = i + 1)
    {
        scanf("%d", &marks[i]);
    }

    printf("The marks for 8 subjects are");
    for (i = 0; i < 8; i = i + 1)
    {
        printf(" %d", marks[i]);
    }
    printf(".\n");

    return 0;
}
