#include <stdio.h>
// What is the output of this program?
// Enter marks: 985
//
int main(void)
{
    int res, marks;
    printf("Enter marks: ");
    res = scanf("%d", &marks);
    printf("%d\n", res);
    return 0;
}
