#include <stdio.h>

int main(void)
{
    int n, i;
    int marks[6] = { 20, 30, 10, 55, 44, 23};
    printf("Enter a number to find index: ");
    scanf("%d", &n);

    for (i = 0; i < 6; i = i + 1)
    {
        if (n == marks[i])
        {
            printf("The index of the %d ", n);
            printf("in array is %d.\n", i);
            break;
        }
    }

    return 0;
}
