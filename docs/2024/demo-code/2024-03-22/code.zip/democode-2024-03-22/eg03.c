#include "telugu.h"

sankya main()
{
    // Example#3
    sankya a = 5;
    sankya b = 10;
    sankya sum = a + b;
    printf("The sum of ");
    printf("%i", a);
    printf(" and ");
    printf("%i", b);
    printf(" is ");
    printf("%i", sum);
    printf(".\n\n");


    printf("The sum of %i and %i is %i.\n\n", a, sum, b);
}
