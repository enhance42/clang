#include "telugu.h"

sankya main()
{
    // Example#5
    int n = 100;
    char ch = 'a';
    float price = 2.50;
    string desam = "Bharat";

    printf("%i\n", n);
    printf("%c\n", ch);
    printf("%f\n", price);
    printf("%s\n", desam);
}
