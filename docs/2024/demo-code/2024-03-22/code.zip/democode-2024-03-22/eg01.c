#include "telugu.h"

sankya main()
{
    // Example#1
    printf("Namasthey Bharat");
    printf("\n");
    printf("Welcome to C");
    printf("\n\n");

    printf("Namasthey Bharat\nWelcome to C\n\n");
}
