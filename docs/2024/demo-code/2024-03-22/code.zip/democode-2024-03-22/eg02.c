#include "telugu.h"

sankya main()
{
    // Example#2
    sankya year = 2024;
    printf("Namasthey Bharat");
    printf("\n");
    printf("Year: %i", year);
    printf("\n\n");

    printf("Namasthey Bharat\nYear: %i\n\n", year);
}
