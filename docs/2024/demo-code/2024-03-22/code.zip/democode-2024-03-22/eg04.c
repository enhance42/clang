#include "telugu.h"

sankya main()
{
    // Example#4
    sankya n = 10;
    printf("The two numbers after %i are %i and %i.\n\n",
          n, n+1, n+2);
}
