#include <stdio.h>

void hintimes(int n); // ela untundhi

int main(void)
{
    hintimes(3);
    printf("Welcome to Online C class.\n");
    hintimes(2); // calling - vadukovadam
    return 0;
}

void hintimes(int n) // Definition - emi chestundhi
{
    while( n > 0)
    {
        printf("Hi\n");
        n = n - 1;
    }
}
