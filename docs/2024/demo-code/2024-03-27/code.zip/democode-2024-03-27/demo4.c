#include <stdio.h>

int main(void)
{
    int marks[3];
    printf("Enter your exam marks for 3 subjects: ");
    scanf("%d", &marks[0]);
    scanf("%d", &marks[1]);
    scanf("%d", &marks[2]);

    printf("The marks for 3 subjects are ");
    printf("%d", marks[0]);
    printf(" %d", marks[1]);
    printf(" %d.\n", marks[2]);

    return 0;
}


/*
#include <stdio.h>

int main(void)
{
    int marks1, marks2, marks3;
    printf("Enter your exam marks for 3 subjects: ");
    scanf("%d", &marks1);
    scanf("%d", &marks2);
    scanf("%d", &marks3);

    printf("The marks for 3 subjects are ");
    printf("%d", marks1);
    printf(" %d", marks2);
    printf(" %d.\n", marks3);

    return 0;
}


*/
