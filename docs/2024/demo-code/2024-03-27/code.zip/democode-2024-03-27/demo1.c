#include <stdio.h>

// User Defined Function  - hi3times, hello3times
// Std C Library Function - printf, scanf
// 3rd Party Function     - send_otp, numberkottu

void hi3times(); // Declare
void hello3times(); // Declare - ela untundhi?

int main(void)
{
    hi3times(); // calling the function
    printf("Welcome to Online C class.\n");
    hello3times(); // calling - vadukovadam
    return 0;
}

void hi3times() // Definition - emi chestundhi
{
    printf("Hi\n");
    printf("Hi\n");
    printf("Hi\n");
}

void hello3times() // Define
{
    printf("Hello\nHello\nHello\n");
}
