#include "telugu.h"

sankya aarambham(gaadidhaguddu)
{
    numberkottu(2048);
    enterkottu();
    
}
