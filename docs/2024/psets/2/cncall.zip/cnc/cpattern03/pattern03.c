#include "telugu.h"

gaadidhaguddu mudusarlu6kottu();
gaadidhaguddu matrix6kottu();

sankya aarambham(gaadidhaguddu)
{
    numberkottu(42);
    enterkottu();

    // use the new commands as
    // many times as needed
    

}

// write the sequence of commands
gaadidhaguddu mudusarlu6kottu()
{

}

// write the sequence of commands
gaadidhaguddu matrix6kottu()
{

}
