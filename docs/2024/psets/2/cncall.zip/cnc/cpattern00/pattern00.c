#include "telugu.h"

// ela untundi kotha command
gaadidhaguddu mudusartlu2kottu();

sankya aarambham(gaadidhaguddu)
{
    numberkottu(42);
    enterkottu();
    enterkottu();

    // use the new commands 
    // two times here
    // ela vadutham kotha command


    enterkottu();
    numberkottu(42);
    enterkottu();
}

// write the sequence of commands
// that needs to be executed
// when we use this command
// emi chestundhi kotha command
gaadidhaguddu mudusartlu2kottu()
{

}