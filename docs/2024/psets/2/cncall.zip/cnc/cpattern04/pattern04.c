#include "telugu.h"

// declartions of new commands
gaadidhaguddu fivedotskottu();
gaadidhaguddu typefirstmatrix();
gaadidhaguddu typesecondmatrix();

sankya aarambham(gaadidhaguddu)
{
    numberkottu(42);
    enterkottu();

    // use the new commands as
    // many times as needed
    
}

// Definitions of new commands
gaadidhaguddu fivedotskottu()
{

}

gaadidhaguddu typefirstmatrix()
{

}

gaadidhaguddu typesecondmatrix()
{

}