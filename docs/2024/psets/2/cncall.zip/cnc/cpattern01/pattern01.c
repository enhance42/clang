#include "telugu.h"

gaadidhaguddu nalugusartlu8kottu();

sankya aarambham(gaadidhaguddu)
{
    numberkottu(42);
    enterkottu();

    // use the new command as
    // many times as needed
    

}

// write the sequence of commands
// that needs to be executed
// when we use this command
gaadidhaguddu nalugusartlu8kottu()
{

}