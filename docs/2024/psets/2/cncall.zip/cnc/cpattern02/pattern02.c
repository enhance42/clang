#include "telugu.h"

gaadidhaguddu typematrix();

sankya aarambham(gaadidhaguddu)
{
    numberkottu(42);
    enterkottu();

    // use the new command as
    // many times as needed
    

}

// define the new command
// typematrix() bellow