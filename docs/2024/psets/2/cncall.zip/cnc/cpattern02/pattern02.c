#include "telugu.h"

gaadidhaguddu matrixkottu();

sankya aarambham(gaadidhaguddu)
{
    numberkottu(42);
    enterkottu();

    // use the new command as
    // many times as needed
    

}

// define the new command
// matrixkottu() bellow